export const add = (a, b) => {
  return a + b;
};
export const minus = (a, b) => {
  console.log("haha");
  return a - b;
};
