import css from "@/index.less";
// import("@babel/polyfill")
import { add } from "./expo.js";
console.log(`${add(10, 10)}`);

// import React, { Component } from "react";
// import ReactDom from "react-dom";

// class App extends Component {
//   render() {
//     return <div>hello React</div>;
//   }
// }

// ReactDom.render(<App />, document.getElementById("app"));
